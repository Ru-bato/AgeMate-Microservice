<template>
    <div class="home-view">
        <NavBar :username="username" :authority="authority" />
        <TopBar :username="username" :authority="authority" />
        <div class="content">
            <router-view />
        </div>
    </div>
</template>

<script setup lang="ts">
import TopBar from '@/components/TopBar.vue'
import NavBar from '@/components/NavBar.vue'
import { defineProps } from 'vue'

const props = defineProps({
    username: {
        type: String,
        required: true,
    },
    authority: {
        type: Number,
        required: true,
    },
})

const username = props.username
const authority = props.authority
</script>

<style scoped>
.home-view {
    display: flex;
}

.content {
    margin-left: 250px;
    padding-top: 60px;
    flex-grow: 1;
    padding: 20px;
    background-color: #ecf0f1;
    min-height: 100vh;
}
</style>