<script setup lang="ts">

</script>

<template>
  <div class="app">
    <router-view></router-view>
  </div>

</template>

<style>
#app {
  overflow: hidden;
  margin: 0 0;
  padding: 0 0;
}
</style>
