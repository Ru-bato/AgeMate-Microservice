<template>
    <div class="home-page">
      <div class="welcome-message">
        <h1>欢迎回来5</h1>
      </div>
    </div>
    </template>

<script setup lang="ts">

</script>